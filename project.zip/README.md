- [Problem Statement](#Problem-Statement)
- [Summary](#Summary)
- [Next Steps](#Next-Steps)
- [Data Dictionary](#Data-Dictionary)
- [External Resources](#External-Resources)

---

## Problem Statement

The Federal Aviation Administration (FAA) uses data from the National Transportation Safety Board 
(NTSB) to evaluate their regulations for civil aviation. The FAA hired our team of data scientists 
to analyze historic aircraft crash data from the NTSB and make predictions that will help them determine 
regulations for the future of aviation safety.

---

## Summary

Aircraft damage prevention might be more cost effective than post damage response. To further examine this relationship,
we ran a logistic regression, Support Vector Machine (SVM), and Random Forest Model. For logistic regression, we used total major
injuries, total minor injuries, total fatal injuries, total uninjuried, and event month to predict aircraft damage level. For 
SVM and random forest model, we used weather condition and broad phase of flight to predict aircraft damage. After finding 
event month, weather condition, phases of flights are good variables used to predict aircraft damage. FAA might consider to
enforce stricter policies to minimize aircraft damages.

<img src="./images/PICTURENAME.png" width="75%" height="75%">

After slicing the initial dataframe to include only the top ten makes, and then the top ten models,
we ran Random Forest and neural network multiclass classifiers to make predictions about the most
common models present in the NTSB crash data in the future. After finding that the Random Forest
classifier had significantly higher accuracy than the baseline model, we found that Piper PA-28
was predicted to be the most common model in future data.

<img src="./Chapter_2/Images/top_10_models.png" width="75%" height="75%">

text

<img src="./images/PICTURENAME.png" width="75%" height="75%">

text

---

### Recommendations

By implementing stricter safety policies, we believe we can drastically reduce the financial loss caused by 
damaged aircrafts, especially those destroyed ones. Additionally, 

---

### Next Steps

text

---

### Data Dictionary

|Feature|Type|Description|
|---|---|---|
|**event_id**|str|unique accident ID|
|**investigation_type**|str|categorical; Accident or Incident|
|**event_date**|time object|month/day/year of occurrence|
|**location**|str|City, State of occurrence|
|**country**|str|United States|
|**airport_code**|str|3-letter airport identifier|
|**airport_name**|str|name of airport|
|**injury_severity**|str|Fatal or Non-Fatal; if Fatal, number of deaths in ()|
|**aircraft_damage**|str|categorical; Substantial, Destroyed, or Minor|
|**aircraft_category**|str|categorical; Airplane, Helicopter, Glider, Balloon, Gyrocraft, Ultralight, Blimp, Powered-Lift, Unknown|
|**registration_number**|str|unique registration ID of aircraft|
|**make**|str|company or individual that produced the aircraft|
|**model**|str|model of aircraft|
|**amateur_built**|int|classification; 1 if yes, 0 if no|
|**number_of_engines**|int|number of aircraft engines; 0, 1, 2, 3 or 4|
|**engine_type**|str|categorical; Reciprocating, Turbo Shaft, Turbo Prop, Turbo Fan, Turbo Jet, Unknown|
|**far_description**|str|type of fare|
|**schedule**|str|categorical; UNK (unknown), NSCH (not scheduled), SCHD (scheduled)|
|**purpose_of_flight**|str|the trip's stated objective|
|**total_fatal_injuries**|int|quantity of fatal injuries (0 if none)|
|**total_serious_injuries**|int|quantity of serious injuries (0 if none)|
|**total_minor_injuries**|int|quantity of minor injuries (0 if none)|
|**total_uninjured**|int|quantity of uninjured passengers (0 if none)|
|**weather_condition**|str|level of damage to aircraft|
|**weather_condition**|str|categorical; VMC (visual meteorological conditions), IMC (instrument meteorological conditions), UNK (unknown)|
|**broad_phase_of_flight**|str|phase of flight when accident occurred|
|**publication_date**|str|date that accident report became available|

---

### External Resources
https://www.ntsb.gov/_layouts/ntsb.aviation/index.aspx  
https://www.faa.gov/about/history/timeline/
http://www.experimentalamateurbuiltaircraftmagazine.com/_media/img/small/t-bird-ii-experimental-amateurbuilt-aircraft012.jpg
http://www.experimentalamateurbuiltaircraftmagazine.com/_media/img/small/x-air-f-experimental-amateurbuilt-aircraft50.jpg
https://www.experimentalamateurbuiltaircraftmagazine.com/_media/img/small/t-bird-ii-experimental-amateurbuilt-aircraft004.jpg
https://i5.walmartimages.com/asr/6e2e3f9d-4e9f-4c2f-ad6e-4f4cdb0b8f7d_1.27b0e501f1b005b422505f963b5cbfb4.jpeg
https://en.wikipedia.org/wiki/Cessna_172
https://en.wikipedia.org/wiki/Piper_PA-28_Cherokee
https://docs.lib.purdue.edu/cgi/viewcontent.cgi?article=1042&context=jate
https://www.beasleyfirm.com/blog/2018/february/the-roles-of-the-faa-and-ntsb-in-plane-crashes/
https://www.faa.gov/documentLibrary/media/Order/FAA_Order_8100.19.pdf
https://www.google.com/search?sxsrf=ALeKk01303d_ZoUTujKBZI0R13aAJTvgYg%3A1605149702082&ei=BqSsX5bNBIHusQXv5Ji4Dw&q=how+much+does+u+lose+if+u+have+to+fix+damaged+aircraft&oq=how+much+does+u+lose+if+u+have+to+fix+damaged+aircraft&gs_lcp=CgZwc3ktYWIQAzoECCMQJzoFCCEQoAE6BQghEKsCOgcIIRAKEKABUKdSWIlcYLBeaABwAXgAgAGMAYgB0QiSAQMyLjiYAQCgAQGqAQdnd3Mtd2l6wAEB&sclient=psy-ab&ved=0ahUKEwiW6LbOgPzsAhUBd6wKHW8yBvcQ4dUDCA0&uact=5
https://www.faa.gov/regulations_policies/handbooks_manuals/aviation/helicopter_flying_handbook/media/hfh_ch13.pdf
https://www.avbuyer.com/articles/engines-biz-av/what-is-turboprop-engine-maintenance-112550
